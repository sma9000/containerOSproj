# Week 9 – Lab 2: Observability and Monitoring

In this lab, we deploy **Prometheus**, **Alertmanager**, and **exporters** to monitor the Voting App.

## Steps
1. Deploy Prometheus
2. Deploy Alertmanager
3. Deploy Redis & Postgres exporters
4. Access Prometheus & Alertmanager
5. Cleanup

Run:
```bash
kubectl apply -f prometheus-configmap.yaml
kubectl apply -f prometheus-deployment.yaml
kubectl apply -f prometheus-service.yaml

kubectl apply -f alertmanager-config.yaml
kubectl apply -f alertmanager-deployment.yaml
kubectl apply -f alertmanager-service.yaml

kubectl apply -f deployment-redis-with-exporter.yaml
kubectl apply -f deployment-postgres-with-exporter.yaml
kubectl apply -f exporters-services.yaml
```

Verify Prometheus: `kubectl port-forward svc/prometheus-service 9090:9090`  
Verify Alertmanager: `kubectl port-forward svc/alertmanager-service 9093:9093`
